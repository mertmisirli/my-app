import React from 'react'

const ProductCard = () => {
  return (
    <div> 
      <p>Product Card</p>

      <div className="card rounded-3 bg-warning">
        <p>Product Name : Text</p>
      </div>
    </div>
  )
}

export default ProductCard
