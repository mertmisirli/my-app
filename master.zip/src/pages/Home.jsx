import React, { useState } from 'react'
import Header from '../components/Header'
import { useSelector } from 'react-redux'
import '../styles/News.css';
import { Link } from 'react-router-dom';

const Home = () => {
    const workoutBanners = useSelector(state => state.workout.workoutBanners)
    const workoutCategories = useSelector(state => state.workout.workoutCategories)

    console.log("Length : ", workoutCategories.length);


    const [slideIndex, setSlideIndex] = useState(0);

    const prevSlide = () => { setSlideIndex((prevIndex) => (prevIndex === 0 ? workoutBanners.length - 1 : prevIndex - 1)); };
    const nextSlide = () => { setSlideIndex((prevIndex) => (prevIndex === workoutBanners.length - 1 ? 0 : prevIndex + 1)); };


    return (
        <div>
            <Header />

            {/* Banner */}
            <div className="d-flex" style={{ width: '100%', position: 'relative' }}>
                {workoutBanners && workoutBanners.length > 0 && workoutBanners.filter((_, index) => index === slideIndex).map((item) => (
                    <div className="card" key={item} style={{ flex: '0 0 100%', height: '250px', padding: '10px' }}>
                        <div style={{ width: '100%', height: '100%', backgroundColor: 'lightgray', display: 'flex', justifyContent: 'center', alignItems: 'center', borderRadius: '5px' }}>
                            <p>{item}</p>
                            <button onClick={prevSlide} style={{ cursor: 'pointer', position: 'absolute', left: '2%', top: '35%', fontSize: '30px' }}>&lt;</button>
                            <button onClick={nextSlide} style={{ cursor: 'pointer', position: 'absolute', right: '2%', top: '35%', fontSize: '30px' }}>&gt;</button>
                        </div>
                    </div>))}
            </div>


            {/* Categories */}
            <div className="row mt-2">
                <div className="d-flex justify-content-between mx-2">
                    {workoutCategories && workoutCategories.length > 0 && workoutCategories.map(c => {
                        return (
                            <Link to={`/category-detail/${c.id}`}>
                                <div className="card workout-card" key={c.category} style={{ height: '150px', width: '150px' }}>
                                    <p className='' style={{ position: 'absolute', bottom: '8%', left: '30%' }}>{c.category}</p>
                                </div>
                            </Link>
                        )
                    })}
                </div>
            </div>

            {/*  */}
            <div className='d-flex' style={{ marginTop: '650px' }}>
                <p className='text-center mx-auto mb-5' style={{ fontSize: '25px' }}>Text</p>
            </div>


        </div>
    )
}

export default Home
