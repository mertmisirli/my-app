
import { BrowserRouter as Router, Routes, Route } from "react-router-dom"
import Product from './pages/Product'
import News from "./pages/News";
import NewsDetail from "./pages/NewsDetail";
import Todo from "./pages/Todo";
import Home from "./pages/Home";
import CategoryDetail from "./pages/CategoryDetail";
import Category from "./pages/Category";

function App() {
  return (
    <div className="">
      <Router>
        <Routes>
          <Route index path="/" element={<Home />}></Route>
          <Route index path="/news" element={<News />}></Route> 
          <Route index path="/news-detail/:id" element={<NewsDetail />}></Route>
          <Route index path="/todo" element={<Todo />}></Route>
          <Route index path="/categories" element={<Category />}></Route>
          <Route index path="/category-detail/:id" element={<CategoryDetail />}></Route>

        </Routes>
      </Router>
    </div>
  );
}

export default App;
