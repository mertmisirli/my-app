import { configureStore } from '@reduxjs/toolkit'
import  dataSlice  from './dataSlice'
import  modalSlice  from './modalSlice'
import  newsSlice  from './newsSlice'
import  orderOptSlice  from './orderSlice'

export const store = configureStore({
  reducer: {
    data : dataSlice,
    modal : modalSlice,
    news : newsSlice,
    order : orderOptSlice,

  },
})